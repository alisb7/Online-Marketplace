<?php
require_once 'config.php';
$email = $_GET['email'];
$get_user = "SELECT * FROM user WHERE email='$email'";
$run_user = mysqli_query($con, $get_user);
$row_user = mysqli_fetch_array($run_user);
$name = $row_user['name'];
$phone = $row_user['phone'];
$address = $row_user['address'];
$postal = $row_user['postal'];
?>
<style>
    body, h4, p {
        font-family: 'Open Sans', sans-serif !important; /* Default font for all text */
    }
    .price {
        font-family: 'Open Sans', sans-serif !important; /* Ensures price uses default font */
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Order Details</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Order Details</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">User Details</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <h5>Name:</h5>
                <p><?php echo($name); ?></p>

                <h5>Email:</h5>
                <p><?php echo($email); ?></p>

                <h5>Phone:</h5>
                <p><?php echo($phone); ?></p>

                <h5>Address:</h5>
                <p><?php echo($address); ?></p>

                <h5>Postal Code:</h5>
                <p><?php echo($postal); ?></p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Order Details</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Price per Unit</th>
                    <th>Total Product Price</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                $get = "SELECT * FROM cart WHERE user_email='$email' AND status='1' AND send_status='0'";
                $run = mysqli_query($con, $get);
                $total1 = 0;
                while($row = mysqli_fetch_array($run)){
                    $pro_id = $row['pro_id'];
                    $count = $row['count'];
                    #
                    $get_pro = "SELECT * FROM pro WHERE id=$pro_id";
                    $run_pro = mysqli_query($con, $get_pro);
                    $row_pro = mysqli_fetch_array($run_pro);
                    $name = $row_pro['name'];
                    $price = $row_pro['price'];
                    $total1 += ($price * $count);
                ?>
                <tr>
                    <td><a target="_blank" href="../pro.php?id=<?php echo($pro_id); ?>"><?php echo($name); ?></a></td>
                    <td><?php echo($count); ?></td>
                    <td><?php echo($price); ?></td>
                    <td><?php echo($count * $price); ?></td>
                </tr>

                <?php } ?>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
            </div>
            <!-- /.card-header -->
            <div class="card-body">
            <h4 class="card-title">Total Payment by User: <?php echo($total1); ?> Toman</h4><br />
            <a class="btn btn-primary btn-block" href="func/change.php?email=<?php echo($email); ?>">Change Order Status</a><br>
            </div>
          </div>
        </div>
      </div>
    </section>
</div>
<!-- /.content-wrapper -->
