<?php
require_once 'config.php';
?>
<style>
    body, h4, p {
        font-family: 'Open Sans', sans-serif !important; /* Default font for all text */
    }
    .price {
        font-family: 'Open Sans', sans-serif !important; /* Ensures price uses default font */
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Delete Product</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Delete Product</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <!-- /.card-header -->
            <div class="card-body">
                <h3 class="text-center">Are you sure you want to delete this product? This action cannot be undone.</h3>
                <!-- /.card-body -->

                <div class="card-footer text-center">
                  <a href="func/del_pro.php?id=<?php echo($_GET['id']); ?>" class="btn btn-warning">Yes, delete it</a>
                  <a href="index.php?pro" class="btn btn-primary">No, go back</a>
                </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
