<?php
$host = 'localhost'; // Your database host
$username = 'root'; // MySQL username
$password = ''; // MySQL password (null)
$database = 'e_com'; // Correct name of your database

// Create connection
$con = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set character set to UTF-8
if (!mysqli_set_charset($con, 'utf8')) {
    echo "Error loading character set utf8: " . mysqli_error($con);
}
?>
